using System.Runtime.CompilerServices;

// make all internals in this assembly also visible to the test assembly(s)
[assembly: InternalsVisibleTo("SamDriver.DrivenDecals.EditorTests")]
