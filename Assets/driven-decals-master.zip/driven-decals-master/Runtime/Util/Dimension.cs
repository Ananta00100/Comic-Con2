using System.Collections.Generic;

namespace SamDriver.Decal
{
    internal enum Dimension
    {
        x,
        y,
        z,
    }
}